# Sofastack Generated Project
This project was generated using [SofaStack](https://github.com/kjalnes/sofastack)
